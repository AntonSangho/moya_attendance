 source .env.sh
