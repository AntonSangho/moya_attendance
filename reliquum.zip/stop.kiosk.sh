sudo systemctl stop kiosk.service
