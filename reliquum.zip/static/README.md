# attendance-system-frontend
RFID Attendance system basic frontend script for our RFID attendance system tutorial.
