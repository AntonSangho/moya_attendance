python3 application.py
