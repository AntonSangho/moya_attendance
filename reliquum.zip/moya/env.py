import os
print(os.getenv('ENV'))

print(os.getenv('DB_HOST'))
print(os.getenv('DB_NAME'))
print(os.getenv('DB_PASSWORD'))
print(os.getenv('DB_USER'))

